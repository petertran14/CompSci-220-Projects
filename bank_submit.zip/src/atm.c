#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "atm.h"
#include "command.h"
#include "trace.h"
#include "errors.h"

// The following functions should be used to read and write
// groups of data over the pipes.  Use them in the implementation
// of the `atm` function below!

// Performs a `write` call, checking for errors and handlings
// partial writes. If there was an error it returns ERR_PIPE_WRITE_ERR.
// Note: data is void * since the actual type being written does not matter.

static int checked_write(int fd, void *data, int n)
{
    char *d = (char *)data;
    while (n > 0)
    {
        int result = write(fd, data, n);
        if (result >= 0)
        {
            // this approach handles both complete and partial writes
            d += result;
            n -= result;
        }
        else
        {
            error_msg(ERR_PIPE_WRITE_ERR,
                      "could not write message to bank");
            return ERR_PIPE_WRITE_ERR;
        }
    }
    return SUCCESS;
}

// Performs a `read` call, checking for errors and handlings
// partial read. If there was an error it returns ERR_PIPE_READ_ERR.
// Note: data is void * since the actual type being read does not matter.

static int checked_read(int fd, void *data, int n)
{
    char *d = (char *)data;
    while (n > 0)
    {
        int result = read(fd, data, n);
        if (result >= 0)
        {
            // this approach handles both complete and partial reads
            d += result;
            n -= result;
        }
        else
        {
            error_msg(ERR_PIPE_READ_ERR,
                      "could not read message from bank");
            return ERR_PIPE_READ_ERR;
        }
    }
    return SUCCESS;
}

// The `atm` function processes commands received from a trace
// file.  It communicates to the bank transactions with a matching
// ID.  It then receives a response from the bank process and handles
// the response appropriately.

// bank_out_fd  - the output file descriptor to which the ATM writes commands to the bank
// atm_in_fd    - the input file descriptor on which the ATM receives commands from the bank
// atm_id       - the ID of the ATM to run
// *cmd         - string associated with a particular command

int atm(int bank_out_fd, int atm_in_fd, int atm_id, Command *cmd)
{
    byte c;
    int i, f, t, a;
    // The atmcmd buffer is used to build messages that are to be sent and received to and from the bank server.
    Command atmcmd;
    Command bankcmd;

    // cmd    - the command buffer to be unpacked.
    // c      - the command type
    // i     - the atm/bank id
    // f   - the from account (if any)
    // t     - the to account (if any)
    // a    - the amount of the transaction (if any)
    cmd_unpack(cmd, &c, &i, &f, &t, &a);

    int status = SUCCESS;

    // TODO: your code here
    // First, you must check to make sure that the ID in the unpacked command is the same as this ATM’s ID.
    // If it is not the same ATM ID then you must return the ERR_UNKNOWN_ATM error code.
    if (atm_id != i) {
        status = ERR_UNKNOWN_ATM;
        return status;
    }
    // Next, you need to handle the logic for each of the commands: CONNECT, EXIT, DEPOSIT, WITHDRAW, TRANSFER, and BALANCE.
    // Each of these commands is handled the same way by the ATM
    if (c == CONNECT) {
        MSG_CONNECT(&bankcmd, atm_id);
    }
    else if (c == EXIT) {
        MSG_EXIT(&bankcmd, atm_id);
    }
    else if (c == DEPOSIT) {
        MSG_DEPOSIT(&bankcmd, atm_id, t, a);
    }
    else if (c == WITHDRAW) {
        MSG_WITHDRAW(&bankcmd, atm_id, f, a);
    }
    else if (c == TRANSFER) {
        MSG_TRANSFER(&bankcmd, atm_id, f, t, a);
    }
    else if (c == BALANCE) {
        MSG_BALANCE(&bankcmd, atm_id, f);
    }
    else {
        status = ERR_UNKNOWN_CMD;
        return status;
    }
    // You will need to use the checked_write function to send the cmd received from the trace file to the bank process.
    if (bank_out_fd < 0) {
        status = ERR_PIPE_WRITE_ERR;
        return status;
    }
    if ((status = checked_write(bank_out_fd, &bankcmd, MESSAGE_SIZE)) == ERR_PIPE_WRITE_ERR) {
        return status;
    }

    if (atm_in_fd < 0) {
        status = ERR_PIPE_READ_ERR;
        return status;
    }
    // You must then read the response from the bank using the checked_read function, into the atmcmd command buffer.
    if ((status = checked_read(atm_in_fd, &atmcmd, MESSAGE_SIZE)) == ERR_PIPE_READ_ERR) {
        return status;
    }

    // If you have successfully received a response from the bank then you need to use cmd_unpack to unpack the
    // command into its individual parts using the variables declared at the beginning of this function.
    cmd_unpack(&atmcmd, &c, &i, &f, &t, &a);

    // OK: Everything was successful and the bank processed the transaction correctly. If so, then you should set status to SUCCESS.
    if (c == OK) {
        status = SUCCESS;
    }

    // NOFUNDS: The bank could not complete the transaction because of insufficient funds. In this case, you should set status to ERR_NOFUNDS.
    else if (c == NOFUNDS) {
        status = ERR_NOFUNDS;
    }

    // ACCUNKN: The bank could not complete the transaction because an account that was used is unknown (invalid account).
    else if (c == ACCUNKN) {
        status = ERR_UNKNOWN_ACCOUNT;
    }

    // If you receive any other command from the bank then you must use the error_msg function (defined in errors.h)
    // to indicate that you received an unknown command (ERR_UNKNOWN_CMD) with an appropriate error message.
    // You should then set the status to ERR_UNKNOWN_CMD.
    else {
        error_msg(ERR_UNKNOWN_CMD, "Error: Unknown Command.");
        status = ERR_UNKNOWN_CMD;
    }

    return status;
}

int atm_run(const char *trace, int bank_out_fd, int atm_in_fd, int atm_id)
{
    int status = trace_open(trace);
    if (status == -1)
    {
        error_msg(ERR_BAD_TRACE_FILE, "could not open trace file");
        return ERR_BAD_TRACE_FILE;
    }

    Command cmd;
    while (trace_read_cmd(&cmd))
    {
        status = atm(bank_out_fd, atm_in_fd, atm_id, &cmd);

        switch (status)
        {

            // We continue if the ATM was unknown. This is ok because the trace
            // file contains commands for all the ATMs.
            case ERR_UNKNOWN_ATM:
                break;

                // We display an error message to the ATM user if the account
                // is not valid.
            case ERR_UNKNOWN_ACCOUNT:
                printf("ATM error: unknown account! ATM Out of service\n");
                break;

                // We display an error message to the ATM user if the account
                // does not have sufficient funds.
            case ERR_NOFUNDS:
                printf("not enough funds, retry transaction\n");
                break;

                // If we receive some other status that is not successful
                // we return with the status.
            default:
                if (status != SUCCESS)
                {
                    printf("status is %d\n", status);
                    return status;
                }
        }
    }

    trace_close();

    return SUCCESS;
}
