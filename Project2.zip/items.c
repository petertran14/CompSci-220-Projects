#include "items.h"

struct Item* itemBuilder(char* name, char* description, struct Item* next) {
    struct Item* current = (struct Item*) malloc(sizeof(struct Item));
    current->name = name;
    current->description = description;
    current->next = next;
    return current;
}

void item_free(struct Item* head) {
    free(head);
}

int getSize(struct Item* list) {
    int size = 0;
    struct Item* temp = list;
    while (temp != NULL) {
        temp = temp->next;
        size = size + 1;
    }
    return size;
}

_Bool isEmpty(struct Item* list) {
    if (getSize(list) == 0) {
        return 1;
    }
    return 0;
}

struct Item* add_item(struct Item* list, struct Item* item) {
    // If the list is empty, the we need to dynamically allocate memory for it.
    if (isEmpty(list)) {
        return itemBuilder(item->name, item->description, item->next);
    }

    // The list was not empty. So I will pushBack().
    struct Item* temp = list;
    // Traverse to the end.
    while (temp->next != NULL) {
        temp = temp->next;
    }
    // Allocate memory for the new item, and have the last item in the list point to it.
    temp->next = itemBuilder(item->name, item->description, item->next);
    return list;
}

struct Item* drop_item(struct Item** list, char* name) {
    //printf("%s", name);
    // If the list is empty, then we can't do this.

    if (isEmpty(*list)) {
        return NULL;
    }

    _Bool first = 1;
    int count = 0;
    int index = 0;
    struct Item* item = *list;
    while (item != NULL && first == 1) {
        if (count == 0) {
            while ((item->name)[index] != '\0') {
                //printf("%c", name[index]);
                if ((item->name)[index] != name[index]) {
                    first = 0;
                }
                index++;
            }
        }
        item = item->next;
        count++;
    }

    // If the item is the first in the list.
    if (first) {
        // Have a pointer to the first item.
        struct Item *temp = *list;
        // Move the item pointer up one.
        *list = (*list)->next;
        // Break the chain of the removed item.
        temp->next = NULL;
        // Return the removed item.
        return temp;
    }

    struct Item* curr = *list;
    struct Item* prev = *list;

    // If the item is not the first in the list.
    while (curr != NULL) {
        if (curr->name == name) {
            struct Item* target = curr;
            prev->next = curr->next;
            target->next = NULL;
            return target;
        }
        prev = curr;
        curr = curr->next;
    }

    // We couldn't find the item to drop.
    return NULL;
}

char* getName(struct Item* list) {
    return list->name;
}

char* getItemDescription(struct Item* list) {
    return list->description;
}

struct Item* getNext(struct Item* list) {
    return list->next;
}