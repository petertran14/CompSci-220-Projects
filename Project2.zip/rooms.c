#include "rooms.h"
#include "items.h"

struct Room* roomBuilder(char* description, struct Item* items, struct Room* north, struct Room* south, struct Room* east, struct Room* west, struct Room* up, struct Room* down, int hasEvent, int hasOmen) {
    struct Room* room = (struct Room*) malloc(sizeof(struct Room));
    room->description = description;
    room->items = items;
    // Initially the room have no omens or events.
    room->hasOmen = hasOmen;
    room->hasEvent = hasEvent;
    room->north = north;
    room->south = south;
    room->east = east;
    room->west = west;
    room->up = up;
    room->down = down;
    return room;
}

void room_free(struct Room* room) {
    free(room);
}

_Bool hasOmen(struct Room* room) {
    return room->hasOmen;
}

_Bool hasEvent(struct Room* room) {
    return room->hasEvent;
}

char* getRoomDescription(struct Room* room) {
    return room->description;
}

struct Item* getItems(struct Room* room) {
    return room->items;
}

struct Room* AddItems(struct Room* room, struct Item* item) {
    struct Item* newList = add_item(room->items, item);
    room->items = newList;
    return room;
}

struct Room* getNorth(struct Room* room) {
    return room->north;
}

struct Room* setNorth(struct Room* current, struct Room* north) {
    current->north = north;
    return current;
}

struct Room* getSouth(struct Room* room) {
    return room->south;
}

struct Room* setSouth(struct Room* current, struct Room* south) {
    current->south = south;
    return current;
}

struct Room* getEast(struct Room* room) {
    return room->east;
}

struct Room* setEast(struct Room* current, struct Room* east) {
    current->east = east;
    return current;
}

struct Room* getWest(struct Room* room) {
    return room->west;
}

struct Room* setWest(struct Room* current, struct Room* west) {
    current->west = west;
    return current;
}

struct Room* getUp(struct Room* room) {
    return room->up;
}

struct Room* setUp(struct Room* current, struct Room* up) {
    current->up = up;
    return current;
}

struct Room* getDown(struct Room* room) {
    return room->down;
}

struct Room* setDown(struct Room* current, struct Room* down) {
    current->down = down;
    return current;
}

