#include <stdlib.h>
#include <stdio.h>

#ifndef PROJECT2_ITEMS_H
#define PROJECT2_ITEMS_H


struct Item {
    char *name;
    char *description;
    struct Item *next;
};

/*
 * Constructor for the structure. It will initialize all the member values if called.
 *
 * @param: name, description, next
 */
struct Item* itemBuilder(char*, char*, struct Item*);

/*
 * De-constructor that frees all the dynamically allocated memory.
 *
 * @param: item
 */
void item_free(struct Item*);

/*
 * Returns the quantity of items in our linked list.
 *
 * @param: list
 * @return: size
 */
int getSize(struct Item*);

/*
 * Returns true if the list is empty, false otherwise.
 *
 * @param: list
 * @return: 0 or 1
 */
_Bool isEmpty(struct Item*);

/*
 * Adds the item to list of items. I am going to pushBack() because I don't know if the item has more stuff attached.
 * Although, it would make sense that we can only pick up one item at a time, so I don't think they will pass
 * me a long list of items to add.
 *
 * @param: list
 * @param: item
 * @return list
 */
struct Item* add_item(struct Item*, struct Item*);

/*
 * Removes the item from the list of items. Returns the item removed, or if unsuccessful, returns NULL.
 *
 * Then I should remember to add the item dropped to the room.
 *
 */
struct Item* drop_item(struct Item**, char*);

/*
 * Returns the name of the current item.
 *
 * @param: list
 * @return: name
 */
char* getName(struct Item*);

/*
 * Returns the description of the item.
 *
 * @param: list
 * @return: description
 */
char* getItemDescription(struct Item*);

/*
 * Returns the next item in the list of items. Returns null if empty.
 *
 * @param: list
 * @return next
 */
struct Item* getNext(struct Item*);

#endif //PROJECT2_ITEMS_H
