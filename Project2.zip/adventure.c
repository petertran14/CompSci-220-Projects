/*
 * Things I know:
 *  - events connect the current room to the starting room.
 *  - items are needed to win.
 *  - omens are needed to win, but do nothing.
 *
 *  - For every malloc(), there should be a free().
 *  - For each room that I make in main(), I should call free() on.
 *      - Made 7 rooms, then need 7 free() in main()
 *  - Does room_free() actually free the items in the scope of main() too?
 *      - Once a pointer is freed, it is freed everywhere.
 *
 *      IMPORTANT: If my takeItem/dropItem command fails...then I can pre-make the items and check by hardcode for their names instead!
 *
 *  - My guess is that a room with an event will always trigger the event process. So, we can trigger multiple events by going back to
 *    a room with an event.
 *
 *    - I can move between rooms, trigger events that will accurately reflect on 'look' command.
 *    - I can take an item in the room and store it in my inventory.
 *    - The problem is that the room does not reflect the fact that I just took an item from it and still displays what
 *      it originally had. I cannot #include anymore files, it will make my computer explode. (Fixed)
 *
 *      - The rooms need to be explored randomly.
 */

#include "rooms.h"
#include "keyword.h"
#include <time.h>

/*
 * If we encounter that the room the avatar is in has an event, then we need to connect the new room to the starting room.
 *
 * @param: avatar
 * @param: start room
 */
void event(struct Avatar*, struct Room*);
void event_helper(struct Avatar*);

int main() {

    _Bool seenOmen = 0;
    int roomsLeft = 6;
    _Bool endGame = 0;

    struct Item* cannedSoup = itemBuilder("soup", "Canned soup fills like no other.", NULL);
    struct Item* knife = itemBuilder("knife", "Will cut your tongue.", NULL);
    struct Item* spoon = itemBuilder("spoon", "Perfect complement for canned soup.", NULL);
    struct Keyword* goComm = buildKeyword("go", NULL);
    struct Keyword* lookUpComm = buildKeyword("lookup", goComm);
    struct Keyword* takeItemComm = buildKeyword("take (Item Name)", lookUpComm);
    struct Keyword* dropItemComm = buildKeyword("drop (Item Name)", takeItemComm);
    struct Keyword* inventoryComm = buildKeyword("inventory", dropItemComm);
    struct Keyword* addComm = buildKeyword("add", inventoryComm);

    struct Room* roomF = roomBuilder("Dimly lit room with food in the fridge.", cannedSoup, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
    struct Room* roomE = roomBuilder("Cold and dark room with cracks on the walls.", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1);
    struct Room* roomD = roomBuilder("Cozy room with a bed but no food.", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
    struct Room* roomC = roomBuilder("Brightly lit room with lot of silverware.", spoon, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
    struct Room* roomB = roomBuilder("Old and musty room with someone inside...", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0);
    struct Room* roomA = roomBuilder("Stinky room with a sandwich nailed to the wall by a knife.", knife, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1);
    struct Room* start = roomBuilder("Clean room with nothing inside.", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);

    struct Avatar* player = buildAvatar(NULL, start, 0);

    printf("Greeting player! Your objective in this game is to traverse through rooms. "
           "You must see at least 1 omen, and have at least 2 items in your inventory, and must be in the starting room in order to win."
           " \nIf you do not meet any of those requirements by the time you have visited 6 new rooms, then you lose."
           " \nRemember to type commands when prompted.");

    printf("\n\nYou are currently in the starting room.\n\n");
    player->currentRoom = start;
    srand(time(0));

    _Bool roomASeen = 0;
    _Bool roomBSeen = 0;
    _Bool roomCSeen = 0;
    _Bool roomDSeen = 0;
    _Bool roomESeen = 0;
    _Bool roomFSeen = 0;

    // Array of pointers.
    struct Room* roomOrder[6];

    int index = 0;
    // While at least one of the rooms has not been assigned an order.
    while (!roomASeen || !roomBSeen || !roomCSeen || !roomDSeen || !roomESeen || !roomFSeen) {
        int randomNumber;
        randomNumber = rand() % 6;
        if (randomNumber == 0 && !roomASeen) {
            roomASeen = 1;
            roomOrder[index] = roomA;
            index++;
        }
        else if (randomNumber == 1 && !roomBSeen) {
            roomBSeen = 1;
            roomOrder[index] = roomB;
            index++;
        }
        else if (randomNumber == 2 && !roomCSeen) {
            roomCSeen = 1;
            roomOrder[index] = roomC;
            index++;
        }
        else if (randomNumber == 3 && !roomDSeen) {
            roomDSeen = 1;
            roomOrder[index] = roomD;
            index++;
        }
        else if (randomNumber == 4 && !roomESeen) {
            roomESeen = 1;
            roomOrder[index] = roomE;
            index++;
        }
        else if (randomNumber == 5 && !roomFSeen) {
            roomFSeen = 1;
            roomOrder[index] = roomF;
            index++;
        }
    }



    while (roomsLeft >= 0 && endGame == 0) {
        char command[20];
        printf("\nPlease enter a built-in command:\nlookup, look, take(ItemName), drop(ItemName), inventory, go(Direction), add(commandName).\n"
               "Please do not enter any whitespace.\n");
        scanf("%s", command);

        // Parse user input for capitalization/lower-case...spell error...whitespace...
        // Ideally the user enters a built in command.
        char buffer[100];
        int count = 0;
        int index = 0;
        while (*(command + count) != '\0') {
            if (*(command + count) == ' ') {
                count++;
            }
            buffer[index] = tolower(*(command + count));
            index++;
            count++;
        }
        // End the command string.
        buffer[index] = '\0';

        // Check for the command 'go' because it requires a unique room to move to.
        if (buffer[0] == 'g' && buffer[1] == 'o' && roomsLeft == 6) {
            _Bool newRoom = 0;
            newRoom = processCommand(addComm, player, roomOrder[0], buffer);
            // Should only decrement the count if we created a new room.
            if (newRoom) {
                roomsLeft = roomsLeft - 1;
                if (roomOrder[0]->hasOmen) {
                    printf("\nSeen Omen!\n");
                    seenOmen = 1;
                }
                if (roomOrder[0]->hasEvent) {
                    printf("\nTriggered Event!\n");
                    event(player, start);
                }
            }
        }
        else if (buffer[0] == 'g' && buffer[1] == 'o' && roomsLeft == 5) {
            _Bool newRoom = 0;
            newRoom = processCommand(addComm, player, roomOrder[1], buffer);
            // Should only decrement the count if we created a new room.
            if (newRoom) {
                roomsLeft = roomsLeft - 1;
                if (roomOrder[1]->hasOmen) {
                    printf("\nSeen Omen!\n");
                    seenOmen = 1;
                }
                if (roomOrder[1]->hasEvent) {
                    printf("\nTriggered Event!\n");
                    event(player, start);
                }
            }
        }
        else if (buffer[0] == 'g' && buffer[1] == 'o' && roomsLeft == 4) {
            _Bool newRoom = 0;
            newRoom = processCommand(addComm, player, roomOrder[2], buffer);
            // Should only decrement the count if we created a new room.
            if (newRoom) {
                roomsLeft = roomsLeft - 1;
                if (roomOrder[2]->hasOmen) {
                    printf("\nSeen Omen!\n");
                    seenOmen = 1;
                }
                if (roomOrder[2]->hasEvent) {
                    printf("\nTriggered Event!\n");
                    event(player, start);
                }
            }
        }
        else if (buffer[0] == 'g' && buffer[1] == 'o' && roomsLeft == 3) {
            _Bool newRoom = 0;
            newRoom = processCommand(addComm, player, roomOrder[3], buffer);
            // Should only decrement the count if we created a new room.
            if (newRoom) {
                roomsLeft = roomsLeft - 1;
                if (roomOrder[3]->hasOmen) {
                    printf("\nSeen Omen!\n");
                    seenOmen = 1;
                }
                if (roomOrder[3]->hasEvent) {
                    printf("\nTriggered Event!\n");
                    event(player, start);
                }
            }
        }
        else if (buffer[0] == 'g' && buffer[1] == 'o' && roomsLeft == 2) {
            _Bool newRoom = 0;
            newRoom = processCommand(addComm, player, roomOrder[4], buffer);
            // Should only decrement the count if we created a new room.
            if (newRoom) {
                roomsLeft = roomsLeft - 1;
                if (roomOrder[4]->hasOmen) {
                    printf("\nSeen Omen!\n");
                    seenOmen = 1;
                }
                if (roomOrder[4]->hasEvent) {
                    printf("\nTriggered Event!\n");
                    event(player, start);
                }
            }
        }
        else if (buffer[0] == 'g' && buffer[1] == 'o' && roomsLeft == 1) {
            _Bool newRoom = 0;
            newRoom = processCommand(addComm, player, roomOrder[5], buffer);
            // Should only decrement the count if we created a new room.
            if (newRoom) {
                roomsLeft = roomsLeft - 1;
                if (roomOrder[5]->hasOmen) {
                    printf("\nSeen Omen!\n");
                    seenOmen = 1;
                }
                if (roomOrder[5]->hasEvent) {
                    printf("\nTriggered Event!\n");
                    event(player, start);
                }
            }
        }
        else {
            if (buffer[0] == 'a' && buffer[1] == 'd' && buffer[2] == 'd') {
                addComm = add(addComm, buffer);
            }
            // All other commands do not rely on the parameter (struct Room*). So I can pass in anything for that.
            processCommand(addComm, player, start, buffer);
        }

        // If the win conditions are met, then end the game.
        if (seenOmen == 1 && player->currentRoom == start && getSize(player->inventory) >= 2) {
            endGame = 1;
        }
    }

    // When we finished the game loop, then we will know the result of the game.
    if (endGame) {
        printf("\n\nYou win!");
    }
    else {
        printf("\n\nYou lose.");
    }

    // Free avatar.
    avatar_free(player);

    // Frees one item at a time.
    item_free(cannedSoup);
    item_free(knife);
    item_free(spoon);

    // Frees the list of commands recursively.
    keyword_free(addComm);

    // Room free needs an individual room and will free one room per call.
    room_free(start);
    room_free(roomA);
    room_free(roomB);
    room_free(roomC);
    room_free(roomD);
    room_free(roomE);
    room_free(roomF);

    return 0;
}

void event(struct Avatar* avatar, struct Room* start) {
    // The new room has an event but is already connected to the starting room.
    if (start->north == avatar->currentRoom || start->south == avatar->currentRoom || start->east == avatar->currentRoom ||
        start->west == avatar->currentRoom || start->up == avatar->currentRoom || start->down == avatar->currentRoom ||
        start->south == avatar->currentRoom) {
        return;
    }
    // The new room has an event and needs to be connected to the starting room.
    if (start->north == NULL) {
        event_helper(avatar);
        start->north = avatar->currentRoom;
        avatar->currentRoom->south = start;
    }
    else if (start->south == NULL) {
        event_helper(avatar);
        start->south = avatar->currentRoom;
        avatar->currentRoom->north = start;
    }
    else if (start->east == NULL) {
        event_helper(avatar);
        start->east = avatar->currentRoom;
        avatar->currentRoom->west = start;
    }
    else if (start->west == NULL) {
        event_helper(avatar);
        start->west = avatar->currentRoom;
        avatar->currentRoom->east = start;
    }
    else if (start->up == NULL) {
        event_helper(avatar);
        start->up = avatar->currentRoom;
        avatar->currentRoom->down = start;
    }
    else if (start->down == NULL) {
        event_helper(avatar);
        start->down = avatar->currentRoom;
        avatar->currentRoom->up = start;
    }
    return;
}

void event_helper(struct Avatar* avatar) {
    struct Room* prev;
    if (avatar->currentRoom->north != NULL) {
        prev = avatar->currentRoom->north;
        prev->south = NULL;
        avatar->currentRoom->north = NULL;
    }
    else if (avatar->currentRoom->south != NULL) {
        prev = avatar->currentRoom->south;
        prev->north = NULL;
        avatar->currentRoom->south = NULL;
    }
    else if (avatar->currentRoom->east != NULL) {
        prev = avatar->currentRoom->east;
        prev->west = NULL;
        avatar->currentRoom->east = NULL;
    }
    else if (avatar->currentRoom->west != NULL) {
        prev = avatar->currentRoom->west;
        prev->east = NULL;
        avatar->currentRoom->west = NULL;
    }
    else if (avatar->currentRoom->up != NULL) {
        prev = avatar->currentRoom->up;
        prev->down = NULL;
        avatar->currentRoom->up = NULL;
    }
    else if (avatar->currentRoom->down != NULL) {
        prev = avatar->currentRoom->down;
        prev->up = NULL;
        avatar->currentRoom->down = NULL;
    }
}
