#include <stdio.h>
#include "items.h"

#ifndef PROJECT2_ROOM_H
#define PROJECT2_ROOM_H

struct Room {
    // We can't go south, but I suppose it would be good to know the room in that direction maybe?
    char* description;
    struct Item* items;
    _Bool hasOmen;
    _Bool hasEvent;
    struct Room* north;
    struct Room* south;
    struct Room* east;
    struct Room* west;
    struct Room* up;
    struct Room* down;
};

// Constructor for the room object.
struct Room* roomBuilder(char*, struct Item*, struct Room*, struct Room*, struct Room*, struct Room*, struct Room*, struct Room*, int, int);

// Deconstructor.
void room_free(struct Room*);

/*
 * Returns true or false whether or not the room has an omen.
 *
 * @param: room
 * @return: bool
 */
_Bool hasOmen(struct Room*);

/*
 * Returns true or false whether or not the room has an event.
 *
 *  * @param: room
 * @return: bool
 */
_Bool hasEvent(struct Room*);

/*
 * Returns the description of the room.
 *
 * @param: room
 * @return: description
 */
char* getRoomDescription(struct Room*);

/*
 * Returns the items contained in the room.
 *
 * @param: room
 * @return: items
 */
struct Item* getItems(struct Room*);

/*
 * Sets the items in the room.
 *
 * @param: room
 * @param: items
 * @return: room
 */
struct Room* AddItems(struct Room*, struct Item*);

/*
 * Returns the room north of the current room. Returns NULL if there is no room.
 *
 * @param: room
 * @return: room
 */
struct Room* getNorth(struct Room*);

/*
 * Our current room will know the room north of it.
 *
 * @param: room
 * @param: room
 * @return: room
 */
struct Room* setNorth(struct Room*, struct Room*);

/*
 * Returns the room south of the current room. Returns NULL if there is no room.
 *
 * @param: room
 * @return: room
 */
struct Room* getSouth(struct Room*);

/*
 * Our current room will know the room south of it.
 *
 * @param: room
 * @param: room
 * @return: room
 */
struct Room* setSouth(struct Room*, struct Room*);

/*
 * Returns the room east of the current room. Returns NULL if there is no room.
 *
 * @param: room
 * @return: room
 */
struct Room* getEast(struct Room*);

/*
 * Our current room will know the room east of it.
 *
 * @param: room
 * @param: room
 * @return: room
 */
struct Room* setEast(struct Room*, struct Room*);

/*
 * Returns the room west of the current room. Returns NULL if there is no room.
 *
 * @param: room
 * @return: room
 */
struct Room* getWest(struct Room*);

/*
 * Our current room will know the room west of it.
 *
 * @param: room
 * @param: room
 * @return: room
 */
struct Room* setWest(struct Room*, struct Room*);

/*
 * Returns the room above of the current room. Returns NULL if there is no room.
 *
 * @param: room
 * @return: room
 */
struct Room* getUp(struct Room*);

/*
 * Our current room will know the room above of it.
 *
 * @param: room
 * @param: room
 * @return: room
 */
struct Room* setUp(struct Room*, struct Room*);

/*
 * Returns the room below of the current room. Returns NULL if there is no room.
 *
 * @param: room
 * @return: room
 */
struct Room* getDown(struct Room*);

/*
 * Our current room will know the room below of it.
 *
 * @param: room
 * @param: room
 * @return: room
 */
struct Room* setDown(struct Room*, struct Room*);

#endif //PROJECT2_ROOM_H
