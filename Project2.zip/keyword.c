#include "keyword.h"

struct Avatar* buildAvatar(struct Item* inventory, struct Room* currRoom, int seenOmen) {
    struct Avatar* avatar = (struct Avatar*) malloc(sizeof(struct Avatar));
    avatar->inventory = inventory;
    avatar->currentRoom = currRoom;
    avatar->seenOmen = seenOmen;
    return avatar;
}

void avatar_free(struct Avatar* avatar) {
    free(avatar);
}

// Build the list manually in main.
struct Keyword* buildKeyword(char* command, struct Keyword* next) {
    struct Keyword* curr = (struct Keyword*) malloc(sizeof(struct Keyword));
    curr->currentCommand = command;
    curr->next = next;
    return curr;
}

// Will free the whole list.
void keyword_free(struct Keyword* list) {
    if (list == NULL) {
        return;
    }
    keyword_free(list->next);
    free(list->next);
}

_Bool processCommand(struct Keyword* list, struct Avatar* avatar, struct Room* room, char* buffer) {
    // Look for the 6 particular built-in commands.
    if (buffer[0] == 'l' && buffer[1] == 'o' && buffer[2] == 'o' && buffer[3] == 'k' &&
             buffer[4] == 'u' && buffer[5] == 'p') {
        lookUp(list);
        return 1;
    }
    else if (buffer[0] == 'l' && buffer[1] == 'o' && buffer[2] == 'o' && buffer[3] == 'k') {
        look(avatar);
        return 1;
    }
    else if (buffer[0] == 't' && buffer[1] == 'a' && buffer[2] == 'k' && buffer[3] == 'e') {
        takeItems(avatar, buffer);
        return 1;
    }
    else if (buffer[0] == 'd' && buffer[1] == 'r' && buffer[2] == 'o' && buffer[3] == 'p') {
        dropItems(avatar, buffer);
        return 1;
    }
    else if (buffer[0] == 'i' && buffer[1] == 'n' && buffer[2] == 'v' && buffer[3] == 'e' &&
             buffer[4] == 'n' && buffer[5] == 't' && buffer[6] == 'o' && buffer[7] == 'r' &&
             buffer[8] == 'y') {
        inventory(avatar);
        return 1;
    }
    else if (buffer[0] == 'g' && buffer[1] == 'o') {
        return go(avatar, room, buffer);
    }
    else if (buffer[0] == 'a' && buffer[1] == 'd' && buffer[2] == 'd') {
        add(list, buffer);
        return 1;
    }

    // Look for commands created by the user that exist but have no functionality. In other words, do nothing.
    else {
        return 0;
    }
}

void lookUp(struct Keyword* list) {
    struct Keyword* temp = list;
    // The added command somehow vanishes here...
    while(temp != NULL) {
        printf("%s\n", temp->currentCommand);
        temp = temp->next;
    }
}

void look(struct Avatar* avatar) {
    // Displays the description of the current room as well as all its items.
    printf("\n\nCurrent Room Description: %s \n", avatar->currentRoom->description);
    printf("Current Room Items: \n");
    if (getSize(avatar->currentRoom->items) == 0) {
        printf("\tNo Items!\n");
    }
    else {
        struct Item* item = avatar->currentRoom->items;
        while(item != NULL) {
            printf("\t%s\n", item->name);
            item = item->next;
        }
    }

    printf("\n");

    // Displays the description of the northern room as well as all its items.
    if (avatar->currentRoom->north == NULL) {
        printf("No room north!\n");
    }
    else {
        // Print room description.
        printf("Northern Room Description: %s \n", avatar->currentRoom->north->description);
        printf("Northern Room Items: \n");
        struct Item* item = avatar->currentRoom->north->items;
        // Print item description.
        if (getSize(item) == 0) {
            printf("\tNo Items!\n");
        }
        else {
            while(item != NULL) {
                printf("\t%s\n", item->name);
                item = item->next;
            }
        }
    }

    printf("\n");

    // Displays the description of the southern room as well as all its items.
    if (avatar->currentRoom->south == NULL) {
        printf("No room south!\n");
    }
    else {
        // Print room description.
        printf("Southern Room Description: %s \n", avatar->currentRoom->south->description);
        printf("Southern Room Items: \n");
        struct Item* item = avatar->currentRoom->south->items;
        // Print item description.
        if (getSize(item) == 0) {
            printf("\tNo Items!\n");
        }
        else {
            while(item != NULL) {
                printf("\t%s\n", item->name);
                item = item->next;
            }
        }
    }

    printf("\n");

    // Displays the description of the eastern room as well as all its items.
    if (avatar->currentRoom->east == NULL) {
        printf("No room east!\n");
    }
    else {
        // Print room description.
        printf("Eastern Room Description: %s \n", avatar->currentRoom->east->description);
        printf("Eastern Room Items: \n");
        struct Item* item = avatar->currentRoom->east->items;
        // Print item description.
        if (getSize(item) == 0) {
            printf("\tNo Items!\n");
        }
        else {
            while(item != NULL) {
                printf("\t%s\n", item->name);
                item = item->next;
            }
        }
    }

    printf("\n");

    // Displays the description of the western room as well as all its items.
    if (avatar->currentRoom->west == NULL) {
        printf("No room west!\n");
    }
    else {
        // Print room description.
        printf("Western Room Description: %s \n", avatar->currentRoom->west->description);
        printf("Western Room Items: \n");
        struct Item* item = avatar->currentRoom->west->items;
        // Print item description.
        if (getSize(item) == 0) {
            printf("\tNo Items!\n");
        }
        else {
            while(item != NULL) {
                printf("\t%s\n", item->name);
                item = item->next;
            }
        }
    }

    printf("\n");

    // Displays the description of the room above as well as all its items.
    if (avatar->currentRoom->up == NULL) {
        printf("No room above!\n");
    }
    else {
        // Print room description.
        printf("Up Room Description: %s \n", avatar->currentRoom->up->description);
        printf("Up Room Items: \n");
        struct Item* item = avatar->currentRoom->up->items;
        // Print item description.
        if (getSize(item) == 0) {
            printf("\tNo Items!\n");
        }
        else {
            while(item != NULL) {
                printf("\t%s\n", item->name);
                item = item->next;
            }
        }
    }

    printf("\n");

    // Displays the description of the room below as well as all its items.
    if (avatar->currentRoom->down == NULL) {
        printf("No room below!\n");
    }
    else {
        // Print room description.
        printf("Down Room Description: %s \n", avatar->currentRoom->down->description);
        printf("Down Room Items: \n");
        struct Item* item = avatar->currentRoom->down->items;
        // Print item description.
        if (getSize(item) == 0) {
            printf("\tNo Items!\n");
        }
        else {
            while(item != NULL) {
                printf("\t%s\n", item->name);
                item = item->next;
            }
        }
    }
}

void takeItems(struct Avatar* avatar, char buffer[]) {

    // List of items from current Room.
    struct Item* list = avatar->currentRoom->items;
    while (list != NULL) {
        // Start comparing at buffer[4].
        int count = 0;
        int index = 4;
        int found = 1;
        // Compare the ITEM chars in the buffer to the name of each item in the list.
        while (buffer[index] != '\0') {
            //printf("%c   ", buffer[index]);
            //printf("%c   ", (list->name)[count]);
            if (buffer[index] != (list->name)[count]) {
                found = 0;
            }
            index++;
            count++;
        }
        // If the item name is found, we have to do pointer surgery to remove it.
        if (found == 1) {
            char itemName[5];
            int i;
            for (i = 4; i < index; i++) {
                itemName[i - 4] = buffer[i];
            }
            itemName[i + 1] = '\0';

            // Remove the item from the room and return the lone item.
            struct Item* take = drop_item(&(avatar->currentRoom->items), itemName);

            // Add the item to the avatar's inventory.
            avatar->inventory = add_item(avatar->inventory, take);
            // Leave function.
            return;
        }
        list = list->next;
    }
    printf("\nItem Not Found.\n");
}

void dropItems(struct Avatar* avatar, char buffer[]) {
    // List of items from avatar Inventory.
    struct Item* list = avatar->inventory;

    while (list != NULL) {
        // Start comparing at buffer[4].
        int count = 0;
        int index = 4;
        int found = 1;
        // Compare the ITEM chars in the buffer to the name of each item in the list.
        while (buffer[index] != '\0') {
            //printf("%c   ", buffer[index]);
            //printf("%c   ", (list->name)[count]);
            if (buffer[index] != (list->name)[count]) {
                found = 0;
            }
            index++;
            count++;
        }
        // If the item name is found, we have to do pointer surgery to remove it.
        if (found == 1) {
            char itemName[10];
            for (int i = 4; i < index; i++) {
                itemName[i - 4] = buffer[i];
            }
            // Remove the item from the avatar and return the lone item.
            struct Item* take = drop_item(&(avatar->inventory), itemName);
            // Add the item to the room.
            avatar->currentRoom->items = add_item(avatar->currentRoom->items, take);
            // Leave function.
            return;
        }
        list = list->next;
    }
    printf("\nItem Not Found.\n");
}
void inventory(struct Avatar* avatar) {
    struct Item* list = avatar->inventory;
    printf("\nInventory:\n");
    if (getSize(list) == 0) {
        printf("No items!\n");
    }
    while(list != NULL) {
        printf("%s\n", list->name);
        list = list->next;
    }
}
_Bool go(struct Avatar* avatar, struct Room* room, char direction[]) {
    if (direction[2] == 'u' && direction[3] == 'p' && direction[4] == '\0') {
        // If we encounter a new room.
        if (avatar->currentRoom->up == NULL) {
            struct Room* prev = avatar->currentRoom;
            avatar->currentRoom->up = room;
            avatar->currentRoom = avatar->currentRoom->up;
            avatar->currentRoom->down = prev;
            return 1;
        }
        // If we encounter a visited room.
        else {
            avatar->currentRoom = avatar->currentRoom->up;
            return 0;
        }
    }
    else if (direction[2] == 'd' && direction[3] == 'o' && direction[4] == 'w' && direction[5] == 'n' && direction[6] == '\0') {
        if (avatar->currentRoom->down == NULL) {
            struct Room* prev = avatar->currentRoom;
            avatar->currentRoom->down = room;
            avatar->currentRoom = avatar->currentRoom->down;
            avatar->currentRoom->up = prev;
            return 1;
        }
        else {
            avatar->currentRoom = avatar->currentRoom->down;
            return 0;
        }
    }
    else if (direction[2] == 'e' && direction[3] == 'a' && direction[4] == 's' && direction[5] == 't' && direction[6] == '\0') {
        if (avatar->currentRoom->east == NULL) {
            struct Room* prev = avatar->currentRoom;
            avatar->currentRoom->east = room;
            avatar->currentRoom = avatar->currentRoom->east;
            avatar->currentRoom->west = prev;
            return 1;
        }
        else {
            avatar->currentRoom = avatar->currentRoom->east;
            return 0;
        }
    }
    else if (direction[2] == 'w' && direction[3] == 'e' && direction[4] == 's' && direction[5] == 't' && direction[6] == '\0') {
        if (avatar->currentRoom->west == NULL) {
            struct Room* prev = avatar->currentRoom;
            avatar->currentRoom->west = room;
            avatar->currentRoom = avatar->currentRoom->west;
            avatar->currentRoom->east = prev;
            return 1;
        }
        else {
            avatar->currentRoom = avatar->currentRoom->west;
            return 0;
        }
    }
    else if (direction[2] == 'n' && direction[3] == 'o' && direction[4] == 'r' && direction[5] == 't' && direction[6] == 'h' && direction[7] == '\0') {
        if (avatar->currentRoom->north == NULL) {
            struct Room* prev = avatar->currentRoom;
            avatar->currentRoom->north = room;
            avatar->currentRoom = avatar->currentRoom->north;
            avatar->currentRoom->south = prev;
            return 1;
        }
        else {
            avatar->currentRoom = avatar->currentRoom->north;
            return 0;
        }
    }
    else if (direction[2] == 's' && direction[3] == 'o' && direction[4] == 'u' && direction[5] == 't' && direction[6] == 'h' && direction[7] == '\0') {
        printf("\nCannot move south.\n");
        return 0;
    }
    else {
        printf("\nPlease give a valid direction.\n");
        return 0;
    }
}
struct Keyword* add(struct Keyword* list, char* command) {
    char array[10];
    int count = 0;
    int index = 3;
    while (command[index] != '\0') {
        array[count] = command[index];
        count++;
        index++;
    }
    array[count] = '\0';

    struct Keyword** temp = &list;
    (*temp)->next = buildKeyword(array, NULL);

    return *temp;
}

