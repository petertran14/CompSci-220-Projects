#include <ctype.h>
#include "items.h"
#include "rooms.h"

#ifndef PROJECT2_KEYWORD_H
#define PROJECT2_KEYWORD_H

/*
 * My assumption with the keyword class is that there is a set of predefined strings that are passed to a function
 * that interprets them and runs the appropriate code, depending on the string.
 */
struct Keyword {
    char* currentCommand;
    struct Keyword* next;
};

struct Avatar {
    struct Item* inventory;
    struct Room* currentRoom;
    _Bool seenOmen;
};

// Constructor
struct Keyword* buildKeyword(char*, struct Keyword*);
struct Avatar* buildAvatar(struct Item*, struct Room*, int);

// Deconstructor
void keyword_free(struct Keyword*);
void avatar_free(struct Avatar*);

/*
 * This takes in a string and calls other specific functions depending on the string input.
 * If the command exists then this function will return true, returns false otherwise.
 *
 * An extremely painful function that is likely riddled with bugs.
 *
 * @param: list (to add to)
 * @param: avatar
 * @param: room (to go to)
 * @param: command (to parse)
 *
 * @return success or fail
 */
_Bool processCommand(struct Keyword*, struct Avatar*, struct Room*, char*);

/*
 * Displays all the commands to the user.
 *
 * @param: list
 */
void lookUp(struct Keyword*);

/*
 * Allows the avatar to see the current room, as well as all the rooms in all directions and all of their items.
 *
 * @param: avatar
 */
void look(struct Avatar*);

/*
 * Searches the current room for the item, if found removes the item from the current room and adds it to the avatar's inventory.
 *
 * Comparing strings in C is a pain.
 *
 * @param: avatar
 * @param: buffer
 */
void takeItems(struct Avatar*, char[]);
/*
 * Searches the avatar's inventory for the item, if found removes the item from the avatar's inventory and adds it to the current room.
 *
 * @param: avatar
 * @param: buffer
 */
void dropItems(struct Avatar*, char[]);

/*
 * Displays the items in the avatar's inventory.
 *
 * @param: avatar
 */
void inventory(struct Avatar*);

/*
 * Moves the avatar to a new room.
 *
 * If the currentRoom->direction is NULL, then we create a new room. Otherwise, we just go to the already created room.
 * Main() will handle if we are out of rooms from the room pile.
 *
 * @param: avatar
 * @param: room
 * @param: direction
 *
 * @return 1, if a room was created, 0, if a room is being re-visited.
 */
_Bool go(struct Avatar*, struct Room*, char[]);

/*
 * Adds a command to the table. Although, for the most part this is useless as I don't know how to dynamically write a function
 * for a command that is declared at run time.
 *
 * @param: list
 * @param: command
 */
struct Keyword* add(struct Keyword*, char*);




#endif //PROJECT2_KEYWORD_H
