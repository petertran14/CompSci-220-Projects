Name: Peter Tran
Project: Thread and Synchronization

Requirements: 
1.  Binary semaphores are used properly to protect critical regions of code.
2. Binary semaphores are used properly not to protect non-critical regions of code.
3. A counting semaphore is used properly to restrict the use of resources (operators).
4. All semaphores are correctly initialized and destroyed.
5. A thread function exists and is implemented properly.
6. Threads are created and joined properly.
7. A global variable next_id exists and is properly updated in the thread function.
8. The phonecall thread properly updates the shared state for the number of connected callers in a critical section.
9. The program prints properly formatted outputs with the variable next_id used as caller’s id.
10. The static modifier is used properly for both thread local variables as well as any global variables.

Firstly, this program requires the user to input a number to the terminal. This number indicates how many times I call pthread_create(), inside a for loop in main(). Of course, I joined all the threads so that there are no zombie threads. In my thread function, I started by initializing all the local variable outside the critical sections. Any data that is modified, I made sure to put it in critical sections. The thread function will connect up to 8 users to a call, and they will order medecine and depending on the order, the threads will begin to finish a few moments later. Meanwhile, callers that must wait for a operator to be available wait for a few seconds, before trying to reconnect again. When a caller hangs up, it makes room for the new caller to join.

1. Binary Semaphores were used in my code whenever I modified data.
2. Declarations of variables that are non critical are outside the binary semaphores.
3. The operator semaphore was used to facilitate the ordering process between the connected callers and the operators.
4. I called sem_init() in the beginning in main(), and sem_destroy() at the end of main().
5. The thread function exists, and produces correct output.
6. I made sure to wait for all threads to finish and join before proceeding in main().
7. I used the global variable and updated it in my thread function.
8. The operator semaphore I used allows multiple (5) callers to engage with the operators simultaneously.
9. All print statements begin with the thread ID.
10. I used all the static variables.

***  YouTube: https://www.youtube.com/watch?v=QJURyni69D0&feature=youtu.be    ***

