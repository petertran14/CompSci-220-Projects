#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <semaphore.h>
#include <unistd.h>

/**
 * Counting Semaphore:
 * The max value that a counting semaphore can take is the the number of processes you want to allow into the
 * critical section at the same time.
 *
 * Binary Semaphore:
 * Binary semaphores are binary, they can have two values only; one to represent that a process/thread is in the
 * critical section(code that access the shared resource) and others should wait, the other indicating the critical section is free.
 */

// Binary Semaphore.
static sem_t connected_lock;
// Counting Semaphore.
static sem_t operators;
static int NUM_OPERATORS = 5;
static int NUM_LINES = 8;
static int connected = 0;    // Callers that are currently connected

// Global variable to ensure unique caller ID's.
int next_id = 0;

// To make things simple initially, write a thread function called phonecall
// that prints a message “this is a phone call” before the thread function ends.
void* phonecall(void *vargp);

int main(int argc, char* argv[]) {
    // This indicates that only 1 thread may be allowed to enter a critical section.
    sem_init(&connected_lock, 0, 1);

    // A counting semaphore, provides a limit of n threads to n resources.
    sem_init(&operators, 0, NUM_OPERATORS);

    // Your main thread function will declare an array of thread id’s (pthread_t) that will represent each phone call.
    // The total number of phone calls should be passed in as a command line argument.
    char* a = argv[1];
    int numThreadID = atoi(a);

    pthread_t tid[numThreadID];

    // Your program then writes a loop calling pthread_create given the phonecall thread function and each corresponding
    // entry of the array of thread id.
    for (int i = 0; i < numThreadID; i++) {
        pthread_create(&tid[i], NULL, phonecall, (void *)&i);
    }

    // After we create each phonecall thread, we want to block the main thread until all the other phonecall threads complete.
    // To do that, you need to write another loop that uses pthread_join on each thread.
    for (int i = 0; i < numThreadID; i++) {
        pthread_join(tid[i], NULL);
    }

    sem_destroy(&connected_lock);
    sem_destroy(&operators);

    return 0;
}

void* phonecall(void *vargp) {
    // For formatting purposes.
    char* s1 = "is attempting to connect...\n";
    char* s2 = "All operators are busy, please wait...\n";
    char* s3 = "connects to an available line, call ringing...\n";
    char* s4 = "is speaking to an operator...\n";
    char* s5 = "has ordered a medecine! The operator has left...\n";
    char* s6 = "has hung up...\n";
    int callerId;

    // Update thread ID, since this modifies data it should be locked in binary semaphore.
    sem_wait(&connected_lock);
    next_id = next_id + 1;
    callerId = next_id;
    printf("Thread %i %s", callerId, s1);
    sem_post(&connected_lock);


    sem_wait(&connected_lock);
    _Bool isConnect = 0;
    // If the thread has not connected, repeat after a short delay.
    while (isConnect == 0) {
        // Line is full, so we wait.
        if (connected == NUM_LINES) {
            sleep(3);
        }
        // We got connected.
        else {
            connected = connected + 1;
            isConnect = 1;
        }
        sem_post(&connected_lock);

        // For the case, where we the line is full and we have to wait, the console will print a message.
        if (isConnect == 0) {
            sem_wait(&connected_lock);
            printf("Thread %i %s", callerId, s2);
            sem_post(&connected_lock);
        }

        // On a successful connection, initiate ordering process.
        else  {
            sem_wait(&operators);

            sem_wait(&connected_lock);
            printf("Thread %i %s", callerId, s3);
            printf("Thread %i %s", callerId, s4);
            sem_post(&connected_lock);

            sleep(1);

            sem_wait(&connected_lock);
            printf("Thread %i %s", callerId, s5);
            sem_post(&connected_lock);

            sem_post(&operators);
        }
    }

    // Update connected.
    sem_wait(&connected_lock);
    connected = connected - 1;
    printf("Thread %i %s", callerId, s6);
    sem_post(&connected_lock);

    return NULL;
 }