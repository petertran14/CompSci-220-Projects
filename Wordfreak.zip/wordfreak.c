#include <fcntl.h>
#include <unistd.h>
#include "words.h"
#include <string.h>
#include <ctype.h>

int main(int argc, char* argv[]) {

    // Controls reading and closing process.
    int fdin, fdout, fdclose, count;
    // Stores one character at a time from the input.
    char buffer[1];
    // 100 million byes. Last ditch effort to read from file.
    char* bigBuffer = malloc(100000000);
    int index = 0;
    // Tree that has the arrangements of words.
    struct WordBinaryTree* tree = NULL;

    printf("Please enter a string:\n");
    char str[100];
    fgets (str, 100, stdin);

    char* token1 = strtok (str," ,.!?:;\"\'-\n");
    while (token1 != NULL)
    {
        int index = 0;
        while (token1[index] != '\0') {
            token1[index] = tolower(token1[index]);
            index++;
        }
        insert(&tree, token1);
        token1 = strtok (NULL, " ,.!?:;\"\'-\n");
    }

    // Get one text file working. Opens file.
    if ((fdin = open(argv[1], O_RDONLY)) < 0) {
        perror("Failed to open file");
        return -1;
    }
    //if ((fdout = open(argv[2], O_WRONLY)) < 0) { return 3; }

    // Reads one character at a time and stores it into the buffer.
    while ((count = read(fdin, buffer, 1)) > 0) {
        if (count < 0) {
            return 4;
        }
        // Store everything into a big buffer.
        bigBuffer[index] = buffer[0];
        index++;
    }
    // Work with one string at a time.
    char* token;
    token = strtok (bigBuffer," ,.!?:;\"\'-\n");
    while (token != NULL)
    {
        int index = 0;
        while (token[index] != '\0') {
            token[index] = tolower(token[index]);
            index++;
        }
        // Pass the token to the insert function.
        insert(&tree, token);
        token = strtok (NULL, " ,.!?:;\"\'-\n");
    }

    //fdout = open(argv[2], O_WRONLY & O_CREAT & O_TRUNC, 0644);
    //int w = write(fdout, &buf[i], cnt)) < cnt

    inOrderDisplay(tree);
    freeBinaryTree(tree);
    free(bigBuffer);

    // Closes the file.
    if ((fdclose = close(fdin)) < 0) {
        perror("Failed to close input file");
        return -1;
    }

//    if (close(fdout) < 0) {
//        perror("Failed to close output file");
//        return -1;
//    }

    return 0;
}
