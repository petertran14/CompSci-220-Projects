#include "words.h"

struct WordBinaryTree* buildWordTree(char* word, int count, struct WordBinaryTree* left, struct WordBinaryTree* right) {
    struct WordBinaryTree* temp = (struct WordBinaryTree*) malloc(sizeof(struct WordBinaryTree));
    temp->word = word;
    temp->count = count;
    temp->left = left;
    temp->right = right;
    return temp;
}

void freeBinaryTree(struct WordBinaryTree* tree) {
    free(tree);
}

void insert(struct WordBinaryTree** tree, char* word) {
    //printf("In Insert, passed in: %s\n", word);
    // Base case: create a new node with the associated word. It should have no children.
    if (*tree == NULL) {
        //printf("In Insert, create new node with: %s\n", word);
        *tree = buildWordTree(word, 1, NULL, NULL);
        return;
    }

    // Base case: we found a duplicate word, so we need to increment the count at the node.
    if (strcmp(word, (*tree)->word) == 0) {
        //printf("In Insert, duplicate of: %s\n", word);
        (*tree)->count = (*tree)->count + 1;
        return;
    }

    else if (strcmp(word, (*tree)->word) < 0) {
        //printf("In Insert, go left with: %s\n", word);
        insert(&((*tree)->left), word);
    }

    else {
        //printf("ROOT: %s\n", (*tree)->word);
        //printf("In Insert, go right with: %s\n", word);
        insert(&((*tree)->right), word);
    }
}

char* getWord(struct WordBinaryTree* tree) {
    return tree->word;
}

int getCount(struct WordBinaryTree* tree) {
    return tree->count;
}

struct WordBinaryTree* getLeft(struct WordBinaryTree* tree) {
    return tree->left;
}

struct WordBinaryTree* getRight(struct WordBinaryTree* tree) {
    return tree->right;
}

void inOrderDisplay(struct WordBinaryTree* tree) {
    if (tree == NULL) {
        return;
    }
    inOrderDisplay(tree->left);
    printf("%s:.....%i\n", tree->word, tree->count);
    inOrderDisplay(tree->right);
}

