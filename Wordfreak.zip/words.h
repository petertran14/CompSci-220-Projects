#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifndef PROJECT3_WORDS_H
#define PROJECT3_WORDS_H

//The TreeNode struct is used to build the tree.
struct WordBinaryTree
{
    char* word;
    int count;
    struct WordBinaryTree* left;
    struct WordBinaryTree* right;
};

// Builds the Tree from the root.
struct WordBinaryTree* buildWordTree(char*, int, struct WordBinaryTree*, struct WordBinaryTree*);

// Frees the tree.
void freeBinaryTree(struct WordBinaryTree*);

/**
 *  Inserts a new node into the tree.
 *
 *  @param: tree
 *  @param: word
 */
void insert(struct WordBinaryTree**, char*);

/**
 * Returns the word in the current node.
 *
 * @return word
 */
char* getWord(struct WordBinaryTree*);

/**
 * Returns the number of times the word was counted in the current node.
 *
 * @return count
 */
int getCount(struct WordBinaryTree*);

/**
 * Returns the left child of the current node.
 *
 * @return node
 */
struct WordBinaryTree* getLeft(struct WordBinaryTree*);

/**
 * Returns the right child of the current node.
 *
 * @return node
 */
struct WordBinaryTree* getRight(struct WordBinaryTree*);

void inOrderDisplay(struct WordBinaryTree*);

#endif //PROJECT3_WORDS_H
