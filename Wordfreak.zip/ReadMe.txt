Name: Peter Tran
Project: WordFreak

I created a word.h and word.c file. These files contain the blueprint and implementation of the binary tree data structure. In particular, the functions that are important in there is insert() and inOrderTraversal(). The tree is made of nodes that also keep track of the quantity of each word. I chose to read the entire text files into a very large buffer. Then I parsed the individual words from the large buffer and inserted them into the binary tree based on lexicographical order. I was able to read from a file and also read user input. Finally I freed all variables that was allocated memory.

I am very sorry but here are some incomplete areas. I was not able to output the results into the output.txt file. I also did not have an environmental variable implemented. Finally, I was not able to chain multiple forms of inputs. 

Youtube: 
https://www.youtube.com/watch?v=ndCxdHa6igk&feature=youtu.be
