#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include "words.h"
#include <ctype.h>

int main(int argc, char* argv[]) {
    struct WordBinaryTree* tree = NULL;
    printf("Please enter a string:\n");
    char str[100];
    fgets (str, 100, stdin);

    char* token = strtok (str," ,.!?:;\"\'-\n");
    while (token != NULL)
    {
        int index = 0;
        while (token[index] != '\0') {
            token[index] = tolower(token[index]);
            index++;
        }
        insert(&tree, token);
        token = strtok (NULL, " ,.!?:;\"\'-\n");
    }

    inOrderDisplay(tree);

    return 0;
}


