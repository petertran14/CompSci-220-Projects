#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

int main (int argc, char *argv[]) {
    int fdin, fdout, cnt, w;
    char buf[1024];
    if (argc != 3) { return 1; }
    if ((fdin  = open(argv[1], O_RDONLY)) < 0) { return 2; }
    if ((fdout = open(argv[2], O_WRONLY)) < 0) { return 3; }
    // Read returns the number of bytes read.
    while ((cnt = read(fdin, buf, 1024)) > 0) {
        if (cnt < 0) { return 4; }
        int i = 0;
        while ((w = write(fdout, &buf[i], cnt)) < cnt) {
            if (w < 0) { return 5; }
            cnt -= w;
            i   += w;
        }
    }
    close(fdin);
    close(fdout);
}



